mod corner_model;
mod cross_solver;
mod cube;
mod edge_model;
mod f2l_solver;
mod full_state;
mod macro_solver;
mod oll_algorithms;
mod oll_solver;
mod pdb;
mod pll_algorithms;
mod search;

use cube::CubeState;
use rand::SeedableRng;

/// Giải OLL: ưu tiên bảng 55 case (nhanh, có tên case); nếu miss thì thử
/// OCLL macro trực tiếp (khi cạnh đã tình cờ đúng hướng); nếu vẫn miss thì
/// rơi về search 2-look tổng quát (pha A + pha B, luôn tìm ra nếu tồn tại
/// trong ngân sách node -- lưới an toàn cuối cùng).
fn solve_oll(full: full_state::FullState) -> Option<(Vec<&'static str>, String)> {
    if let Some((prefix, mvs, name)) = oll_algorithms::solve_oll_with_auf(full) {
        let mut all = prefix;
        all.extend(mvs);
        return Some((all, format!("named:{name}")));
    }
    if full_state::u_edges_oriented(&full) {
        if let Some(mvs) = macro_solver::solve_ocll_macro(full, 4) {
            return Some((mvs, "ocll_macro".to_string()));
        }
    }
    oll_solver::solve_oll_search(full).map(|m| (m, "search_2look".to_string()))
}

/// Giải PLL: ưu tiên bảng 47 mục (nhanh, có tên case); nếu miss thì dùng
/// macro fallback (T/Y-perm + 3-cycle × AUF) -- theo Python, gần như luôn
/// thành công (200/200 case tổng hợp + 10/10 case thật).
fn solve_pll(full: full_state::FullState) -> Option<(Vec<&'static str>, String)> {
    let (mvs, name) = pll_algorithms::solve_pll_lookup_named(full);
    if let Some(m) = mvs {
        return Some((m, format!("named:{}", name.unwrap())));
    }
    macro_solver::solve_pll_macro(full, 4).map(|m| (m, "macro".to_string()))
}

/// Giải trọn vẹn 1 cube đã scramble: Cross -> F2L -> OLL -> PLL. Nếu OLL
/// hoặc PLL "bí" (mọi lưới an toàn đều miss -- cực hiếm sau khi đã có
/// macro fallback), THỬ LẠI F2L với thứ tự nước đi xáo trộn (retry_seed
/// khác) để hội tụ về 1 trạng thái OLL/PLL khác dễ hơn -- đúng cơ chế
/// `retry=True` trong search_utils.py/f2l_solver.py bản Python (tìm kiếm
/// vốn tất định nên "thử lại y hệt" vô nghĩa, phải xáo trộn thứ tự).
/// Trả về (tổng số nước, các nguồn đã dùng) hoặc None nếu cả max_retries
/// lần đều thất bại.
fn solve_full_cube(scramble_seed: u64, max_retries: u32) -> Option<(usize, Vec<String>)> {
    let mut s0 = CubeState::solved();
    let mut r = rand::rngs::StdRng::seed_from_u64(scramble_seed);
    cube::random_scramble_moves(&mut s0, 25, &mut r);
    let cm = cross_solver::solve_cross(&s0, 20);
    s0.apply_sequence(&cm);
    let f_after_cross = full_state::from_facelets(&s0);

    for attempt in 0..=max_retries {
        let mut s = s0;
        let retry_seed = if attempt == 0 { None } else { Some(scramble_seed * 1000 + attempt as u64) };
        let res = f2l_solver::solve_f2l_seeded(f_after_cross, &[8, 10, 12, 14], 400_000, retry_seed);
        s.apply_sequence(&res.moves);
        if res.solved_slots.len() != 4 {
            continue;
        }
        let f2 = full_state::from_facelets(&s);
        let (oll_mvs, oll_src) = match solve_oll(f2) {
            Some(x) => x,
            None => continue,
        };
        s.apply_sequence(&oll_mvs);
        let f3 = full_state::from_facelets(&s);
        let (pll_mvs, pll_src) = match solve_pll(f3) {
            Some(x) => x,
            None => continue,
        };
        s.apply_sequence(&pll_mvs);
        if s.is_solved() {
            let total = cm.len() + res.moves.len() + oll_mvs.len() + pll_mvs.len();
            return Some((total, vec![format!("attempt={attempt}"), oll_src, pll_src]));
        }
    }
    None
}

fn main() {
    use std::time::Instant;

    // Warm up PDB (giống Python đã load cache đĩa trước khi solve) --
    // KHÔNG tính vào thời gian "solve" để so sánh công bằng với Python
    // (Python build 1 lần, cache ra .pkl, các lần sau load lại).
    let t_pdb0 = Instant::now();
    cross_solver::get_pdb();
    f2l_solver::warm_pair_pdbs();
    println!("PDB warm-up: {:?}", t_pdb0.elapsed());

    let mut st = CubeState::solved();
    let mut rng = rand::rngs::StdRng::seed_from_u64(123);
    let scramble = cube::random_scramble_moves(&mut st, 25, &mut rng);
    println!("Scramble: {}", scramble.join(" "));

    let t0 = Instant::now();
    let cross_moves = cross_solver::solve_cross(&st, 20);
    st.apply_sequence(&cross_moves);
    let t_cross = t0.elapsed();

    let t1 = Instant::now();
    let full = full_state::from_facelets(&st);
    let result = f2l_solver::solve_f2l(full, &[8, 10, 12, 14], 200_000);
    st.apply_sequence(&result.moves);
    let t_f2l = t1.elapsed();

    println!("Cross ({} moves, {:?}): {}", cross_moves.len(), t_cross, cross_moves.join(" "));
    println!("F2L ({} moves, {:?}): {}", result.moves.len(), t_f2l, result.moves.join(" "));
    println!("F2L solved slots: {:?}", result.solved_slots);

    let t2 = Instant::now();
    let full_before_oll = full_state::from_facelets(&st);
    let oll = solve_oll(full_before_oll);
    let t_oll = t2.elapsed();
    match &oll {
        Some((moves, source)) => {
            st.apply_sequence(moves);
            println!("OLL [{source}] ({} moves, {:?}): {}", moves.len(), t_oll, moves.join(" "));
        }
        None => println!("OLL: khong giai duoc (ca bang lan macro fallback deu miss)"),
    }

    let t3 = Instant::now();
    let full_before_pll = full_state::from_facelets(&st);
    let pll = solve_pll(full_before_pll);
    let t_pll = t3.elapsed();
    match &pll {
        Some((moves, source)) => {
            st.apply_sequence(moves);
            println!("PLL [{source}] ({} moves, {:?}): {}", moves.len(), t_pll, moves.join(" "));
        }
        None => println!("PLL: khong giai duoc (ca bang lan macro fallback deu miss)"),
    }

    println!("Total solve time (no PDB build): {:?}", t_cross + t_f2l + t_oll + t_pll);
    println!("CUBE SOLVED: {}", st.is_solved());

    // ── Batch benchmark: 50 scramble ngẫu nhiên, chỉ tính thời gian solve
    // (PDB đã warm) -- so sánh công bằng với benchmark Python tương đương.
    let n = 50;
    let t_batch = Instant::now();
    let mut total_cross_moves = 0usize;
    let mut total_f2l_moves = 0usize;
    let mut solved_count = 0usize;
    for seed in 0..n {
        let mut s = CubeState::solved();
        let mut r = rand::rngs::StdRng::seed_from_u64(1000 + seed);
        cube::random_scramble_moves(&mut s, 25, &mut r);
        let cm = cross_solver::solve_cross(&s, 20);
        s.apply_sequence(&cm);
        total_cross_moves += cm.len();
        let f = full_state::from_facelets(&s);
        let res = f2l_solver::solve_f2l(f, &[8, 10, 12, 14], 200_000);
        s.apply_sequence(&res.moves);
        total_f2l_moves += res.moves.len();
        if res.solved_slots.len() == 4 {
            solved_count += 1;
        }
    }
    let elapsed = t_batch.elapsed();
    let total_nodes = f2l_solver::NODES_SEEN.load(std::sync::atomic::Ordering::Relaxed);
    println!(
        "\nBatch {n} scrambles: {:?} total ({:?}/scramble avg), {solved_count}/{n} fully solved F2L, avg cross={:.1} avg f2l={:.1}",
        elapsed,
        elapsed / n as u32,
        total_cross_moves as f64 / n as f64,
        total_f2l_moves as f64 / n as f64
    );
    println!(
        "Total A* nodes expanded: {total_nodes} ({:.0} nodes/scramble, {:.1} ns/node)",
        total_nodes as f64 / n as f64,
        elapsed.as_nanos() as f64 / total_nodes as f64
    );

    // ── Batch full-cube-solve: 200 scramble, đo tỉ lệ giải trọn vẹn cube
    // (Cross+F2L+OLL+PLL), có retry F2L (toi da 2 lan) khi OLL/PLL bi.
    let n2 = 200;
    let mut full_solved = 0usize;
    let mut needed_retry = 0usize;
    for seed in 0..n2 {
        match solve_full_cube(5000 + seed, 2) {
            Some((_total, info)) => {
                full_solved += 1;
                if info[0] != "attempt=0" {
                    needed_retry += 1;
                }
            }
            None => {}
        }
    }
    println!(
        "\nFull-solve batch {n2} scrambles: {full_solved}/{n2} giai tron ven (can retry F2L: {needed_retry})"
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn edge_move_table_matches_python_reference() {
        let t = edge_model::tables();
        let mi = cube::move_index("R");
        assert_eq!(t.perm[mi], [0, 1, 2, 10, 4, 5, 6, 8, 3, 9, 7, 11]);
        assert_eq!(t.flip[mi], [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0]);
    }

    #[test]
    fn corner_move_table_matches_python_reference() {
        let t = corner_model::tables();
        let mi = cube::move_index("R");
        assert_eq!(t.perm[mi], [2, 1, 6, 3, 0, 5, 4, 7]);
        assert_eq!(t.ori_delta[mi], [2, 0, 1, 0, 1, 0, 2, 0]);
    }

    #[test]
    fn cross_pdb_size_matches_python_reference() {
        let pdb = cross_solver::get_pdb();
        assert_eq!(pdb.len(), 190_080);
        assert_eq!(pdb.max_dist(), 8u16);
    }

    #[test]
    fn pair_pdb_size_matches_python_reference() {
        let pdb = pdb::build_pdb_pair("DFR", "FR");
        assert_eq!(pdb.len(), 576);
        assert_eq!(pdb.max_dist(), 6u16);
    }

    #[test]
    fn solved_cube_has_zero_cross_distance() {
        let st = CubeState::solved();
        let mvs = cross_solver::solve_cross(&st, 20);
        assert!(mvs.is_empty());
    }

    #[test]
    fn cross_solver_solves_cross_on_scramble() {
        let mut st = CubeState::solved();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        cube::random_scramble_moves(&mut st, 20, &mut rng);
        let mvs = cross_solver::solve_cross(&st, 20);
        assert!(mvs.len() <= 8);
        st.apply_sequence(&mvs);
        let full = full_state::from_facelets(&st);
        assert!(full_state::cross_ok(&full));
    }

    #[test]
    fn f2l_solver_completes_all_slots_after_cross() {
        let mut st = CubeState::solved();
        let mut rng = rand::rngs::StdRng::seed_from_u64(2);
        cube::random_scramble_moves(&mut st, 20, &mut rng);

        let cross_mvs = cross_solver::solve_cross(&st, 20);
        st.apply_sequence(&cross_mvs);

        let full = full_state::from_facelets(&st);
        let result = f2l_solver::solve_f2l(full, &[8, 10, 12, 14], 200_000);

        assert_eq!(result.solved_slots.len(), 4);
        st.apply_sequence(&result.moves);
        let full_after = full_state::from_facelets(&st);
        assert!(full_state::cross_f2l_ok(&full_after));
    }

    #[test]
    fn f2l_solver_is_noop_when_already_solved() {
        let st = CubeState::solved();
        let full = full_state::from_facelets(&st);
        let result = f2l_solver::solve_f2l(full, &[8, 10, 12, 14], 200_000);
        assert!(result.moves.is_empty());
        assert_eq!(result.solved_slots.len(), 4);
    }

    #[test]
    fn oll_group_pdb_sizes_match_python_reference() {
        // Python: edge pdb size 190080 max 4; corner pdb size 136080 max 4.
        let ep = crate::pdb::build_group_pdb_edges_anyperm();
        assert_eq!(ep.len(), 190_080);
        assert_eq!(ep.max_dist(), 4);
    }

    #[test]
    fn corner_group_pdb_size_matches_python_reference() {
        let cp = crate::pdb::build_group_pdb_corners_anyperm();
        assert_eq!(cp.len(), 136_080);
        assert_eq!(cp.max_dist(), 4);
    }

    #[test]
    fn oll_table_size_matches_python_reference() {
        // Python: OLL verified 55, table size 55 (khong trung key).
        let t = oll_algorithms::table();
        assert_eq!(t.table.len(), 55);
    }

    #[test]
    fn pll_table_size_matches_python_reference() {
        // Python: PLL verified 21, table size 47.
        let t = pll_algorithms::table();
        assert_eq!(t.table.len(), 47);
    }

    #[test]
    fn oll_solves_sune_case() {
        let mut st = CubeState::solved();
        st.apply_sequence(&["R", "U", "R'", "U", "R", "U2", "R'"]);
        let full = full_state::from_facelets(&st);
        let (prefix, mvs, name) = oll_algorithms::solve_oll_with_auf(full).unwrap();
        st.apply_sequence(&prefix);
        st.apply_sequence(&mvs);
        // Doi chieu voi Python: solve_oll_with_auf() tren state nay tra ve
        // 'AntiSune' (khong phai 'Sune') -- da xac nhan Python CUNG tra ve
        // dung ten nay (khop bang theo TRANG THAI can giai, khong phai
        // theo ten nuoc da tao ra no).
        assert_eq!(name, "AntiSune");
        let full_after = full_state::from_facelets(&st);
        assert!(full_state::cross_f2l_ok(&full_after));
        let (_, eo, _, co) = full_after;
        assert_eq!(&eo[0..4], &[0, 0, 0, 0]);
        assert_eq!(&co[0..4], &[0, 0, 0, 0]);
    }

    #[test]
    fn pll_reports_solved_when_last_layer_already_permuted() {
        let st = CubeState::solved();
        let full = full_state::from_facelets(&st);
        let (mvs, name) = pll_algorithms::solve_pll_lookup_named(full);
        assert_eq!(mvs, Some(vec![]));
        assert_eq!(name, Some("solved"));
    }

    #[test]
    fn pll_solves_tperm_case() {
        let mut st = CubeState::solved();
        // T-perm: hoan vi thuan, ap dung se tao 1 case PLL that.
        st.apply_sequence(&["R", "U", "R'", "U'", "R'", "F", "R2", "U'", "R'", "U'", "R", "U", "R'", "F'"]);
        let full = full_state::from_facelets(&st);
        let (mvs, name) = pll_algorithms::solve_pll_lookup_named(full);
        assert!(mvs.is_some());
        assert!(name.is_some());
        st.apply_sequence(&mvs.unwrap());
        assert!(st.is_solved());
    }

    #[test]
    fn full_cfop_pipeline_solves_cube_when_lookup_tables_cover_the_case() {
        // Chay nhieu seed, chi assert cube da SOLVED cho nhung case ma
        // ca OLL lan PLL deu co trong bang (bang chua day du 57/21 case
        // OLL/dieu kien bien -- xem oll_algorithms.rs).
        let mut any_full_solve = false;
        for seed in 0..30u64 {
            let mut st = CubeState::solved();
            let mut r = rand::rngs::StdRng::seed_from_u64(9000 + seed);
            cube::random_scramble_moves(&mut st, 25, &mut r);

            let cm = cross_solver::solve_cross(&st, 20);
            st.apply_sequence(&cm);
            let f = full_state::from_facelets(&st);
            let res = f2l_solver::solve_f2l(f, &[8, 10, 12, 14], 200_000);
            st.apply_sequence(&res.moves);
            if res.solved_slots.len() != 4 {
                continue;
            }

            let f2 = full_state::from_facelets(&st);
            let oll = match oll_algorithms::solve_oll_with_auf(f2) {
                Some(x) => x,
                None => continue,
            };
            st.apply_sequence(&oll.0);
            st.apply_sequence(&oll.1);

            let f3 = full_state::from_facelets(&st);
            let (pll_mvs, _) = pll_algorithms::solve_pll_lookup_named(f3);
            let mvs = match pll_mvs {
                Some(m) => m,
                None => continue,
            };
            st.apply_sequence(&mvs);

            assert!(st.is_solved(), "seed {seed}: pipeline ket thuc nhung cube CHUA solved (bug)");
            any_full_solve = true;
        }
        assert!(any_full_solve, "khong seed nao duoc bang lookup bao phu du de test co y nghia");
    }

    #[test]
    fn ocll_macro_solves_corner_orientation() {
        let mut st = CubeState::solved();
        st.apply_sequence(&["R", "U", "R'", "U", "R", "U2", "R'"]);
        let full = full_state::from_facelets(&st);
        assert!(full_state::u_edges_oriented(&full));
        let mvs = macro_solver::solve_ocll_macro(full, 4).unwrap();
        st.apply_sequence(&mvs);
        let full_after = full_state::from_facelets(&st);
        assert!(full_state::u_corners_oriented(&full_after));
        assert!(full_state::cross_f2l_ok(&full_after));
    }

    #[test]
    fn pll_macro_solves_when_lookup_would_miss() {
        let mut st = CubeState::solved();
        st.apply_sequence(&["R'", "F", "R'", "B2", "R", "F'", "R'", "B2", "R2"]); // Aa
        st.apply_sequence(&["R", "U'", "R", "U", "R", "U", "R", "U'", "R'", "U'", "R2"]); // Edge3
        let full = full_state::from_facelets(&st);
        let mvs = macro_solver::solve_pll_macro(full, 4).expect("macro fallback phai giai duoc");
        st.apply_sequence(&mvs);
        assert!(st.is_solved());
    }

    #[test]
    fn full_cfop_pipeline_with_macro_fallback_beats_lookup_only_coverage() {
        let mut solved_count = 0u32;
        let n = 60u64;
        for seed in 0..n {
            let mut st = CubeState::solved();
            let mut r = rand::rngs::StdRng::seed_from_u64(9000 + seed);
            cube::random_scramble_moves(&mut st, 25, &mut r);

            let cm = cross_solver::solve_cross(&st, 20);
            st.apply_sequence(&cm);
            let f = full_state::from_facelets(&st);
            let res = f2l_solver::solve_f2l(f, &[8, 10, 12, 14], 200_000);
            st.apply_sequence(&res.moves);
            if res.solved_slots.len() != 4 {
                continue;
            }

            let f2 = full_state::from_facelets(&st);
            let (oll_mvs, _) = match solve_oll(f2) {
                Some(x) => x,
                None => continue,
            };
            st.apply_sequence(&oll_mvs);

            let f3 = full_state::from_facelets(&st);
            let (pll_mvs, _) = match solve_pll(f3) {
                Some(x) => x,
                None => continue,
            };
            st.apply_sequence(&pll_mvs);

            assert!(st.is_solved(), "seed {seed}: pipeline ket thuc nhung cube CHUA solved (bug)");
            solved_count += 1;
        }
        assert!(solved_count as f64 / n as f64 > 0.8, "ty le giai tron ven qua thap: {solved_count}/{n}");
    }

    #[test]
    fn full_cube_solve_with_retry_reaches_near_100_percent() {
        let n = 60u64;
        let mut solved = 0u32;
        for seed in 0..n {
            if solve_full_cube(5000 + seed, 2).is_some() {
                solved += 1;
            }
        }
        // Da do thuc te: co retry (toi da 2 lan) dat ~90% (54/60). Con lai
        // la cac case OLL "Dot" kho (0 canh dung huong) ma A* pha A chua
        // du manh -- xem ghi chu trong lich su trao doi / README. Nguong
        // duoi day phan anh dung thuc te da do, khong phai muc tieu ly
        // tuong -- xem do la viec CON LAI, khong phai da xong.
        assert!(solved as f64 / n as f64 >= 0.85, "ty le giai tron ven (co retry) qua thap: {solved}/{n}");
    }
}









#[cfg(test)]
mod final_verification {
    use super::*;

    /// Kiem tra hoi quy: ty le giai tron ven phai o muc cao (da do thuc te
    /// 99% sau khi sua bug F2L "quen them slot da xong vao done" + tang
    /// node budget 200k->400k). Nguong 95% de con it du dia an toan cho
    /// bien dong seed/timing, khong phai muc tieu ly tuong.
    #[test]
    fn batch_200_success_rate() {
        let n = 200u64;
        let mut solved = 0u32;
        for seed in 0..n {
            if solve_full_cube(5000 + seed, 2).is_some() {
                solved += 1;
            }
        }
        let rate = solved as f64 / n as f64;
        assert!(rate >= 0.95, "ty le giai tron ven qua thap: {solved}/{n} ({:.1}%)", rate * 100.0);
    }
}
