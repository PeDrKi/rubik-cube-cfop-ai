# Cách chạy trên máy bạn

```powershell
cd rubik-render-windowed
cargo run --release
```

## Giao diện
- **Panel trái**: khung 6 mặt (bố cục chữ thập U/L/F/R/B/D) + thanh nhập
  công thức Singmaster + nút Áp dụng/Xóa + trạng thái.
- **Panel phải**: cube 3D, kéo chuột xoay, cuộn zoom.

## Điều khiển
- **Click vào ô nhập, gõ công thức** (VD: `R U R' U'`, hỗ trợ `(...)n`
  lặp nhóm), bấm Enter hoặc nút "Áp dụng" -- cube animate đúng chuỗi đó.
- **U D F B L R** (khi KHÔNG focus ô nhập): xoay lớp trực tiếp bằng phím.
  **Shift + phím đó**: nước nghịch đảo.
- **Space**: xáo cube 25 nước ngẫu nhiên.
- **Enter** (khi KHÔNG focus ô nhập): AI tự giải từ trạng thái hiện tại.

## Đã xác thực (không chỉ "chạy không lỗi")
- Chụp màn hình thật qua Xvfb, mô phỏng click+gõ+Enter bằng xdotool, đối
  chiếu kết quả `R U R' U'` với `cube_engine.py` -- khớp tuyệt đối từng
  facelet trên cả 6 mặt.
- Phát hiện và sửa 1 bug thật: bấm Enter trong ô nhập công thức trước đây
  vô tình TRIGGER LUÔN phím tắt "AI tự giải" toàn cục (do cờ `handled`
  của egui không đáng tin cậy đúng lúc ô nhập vừa mất focus), khiến hàng
  đợi vừa nạp bị xóa sạch. Đã sửa bằng cách tự theo dõi trạng thái
  focus/lost_focus của ô nhập thay vì dựa vào egui.

## Vẫn còn thiếu (biết trước)
- Enter (AI giải) làm khựng khung hình trong lúc tính (chưa chạy nền).
- ~5-10% case AI không giải được (giới hạn thuật toán OLL khó, xem
  rubik-rs).
- Chưa hỗ trợ M/E/S/wide/rotation qua PHÍM TẮT riêng (chỉ U/D/F/B/L/R có
  phím). Nhưng nếu công thức trong thanh nhập chứa M/E/S/x/y/z/u/d/f/b/l/r,
  chúng VẪN animate được (move_spec đã hỗ trợ đủ 18+6 nước) -- điểm CHƯA
  kiểm chứng là hướng xoay hiển thị của riêng các nước này có đúng chiều
  hay không (chỉ U đã được đối chiếu kỹ với Python). Dù animation có lỡ
  sai chiều, TRẠNG THÁI CUBE CUỐI CÙNG vẫn luôn đúng, vì được áp dụng qua
  `cube.rs::do_move()` (engine đã kiểm chứng), độc lập với animation.

## Tính năng Gợi ý (H) -- mới thêm
Port của tính năng Hint bản Python: chỉ tính BƯỚC TIẾP THEO duy nhất
(Cross / 1 cặp F2L / OLL-cạnh / OLL-góc / PLL), KHÔNG tự động thực thi.
- Bấm phím **H** hoặc nút "Gợi ý (H)" trong panel trái.
- Panel hiện tên bước + công thức Singmaster của bước đó.
- Bấm "Áp dụng gợi ý" nếu muốn cube tự animate đúng bước đó (hoặc bạn tự
  xoay tay theo công thức hiển thị).
- Đã kiểm chứng qua ảnh chụp thật (Xvfb + xdotool): xáo cube, bấm Gợi ý
  ra đúng "Cross" kèm công thức hợp lệ, bấm Áp dụng gợi ý animate đúng.

## F11 / Resize / Undo -- mới thêm

- **F11**: bật/tắt toàn màn hình thật (winit `set_fullscreen`). Lưu ý kỹ
  thuật: `three-d` bản 0.17 không cho truy cập lại cửa sổ winit gốc sau
  khi tạo, nên phần này viết lại toàn bộ vòng lặp render bằng API cấp
  thấp (`WindowedContext` + `FrameInputGenerator`) thay vì
  `Window::render_loop()` tiện lợi trước đây -- hành vi các tính năng
  khác không đổi, chỉ đổi phần "vỏ" quản lý cửa sổ.
- **Resize**: cửa sổ giờ resize tự do được (trước đó cũng đã resize
  được, nhưng chưa xác nhận rõ ràng). Panel trái giữ cố định 300px,
  vùng 3D + camera tự động co giãn theo phần còn lại.
- **Ctrl+Z (Undo)**: hoàn tác 1 "hành động" (1 nước tay, cả 1 công thức,
  cả 1 lần AI giải, cả 1 lần áp dụng gợi ý -- không phải từng nước lẻ
  trong đó), giới hạn 120 bước giống bản Python (`UNDO_MAX`). Số bước
  undo còn lại hiển thị trong panel trái.

Đã kiểm chứng cả 3 bằng ảnh chụp thật qua Xvfb + xdotool:
- Undo: xoay U rồi F, chụp ảnh; Ctrl+Z lần 1 → đúng trạng thái sau U
  (đối chiếu: mặt F hàng trên phải là màu R cũ = cam, khớp); Ctrl+Z lần
  2 → về đúng solved.
- F11: phải cài thêm 1 window manager thật (fluxbox) vào môi trường test
  vì Xvfb trần không có WM (fullscreen X11 vốn cần WM hợp tác) -- sau đó
  xác nhận: cửa sổ từ `1100x800 tại (1,45)` (có tiêu đề) chuyển thành
  `1600x1000 tại (0,0)` (phủ kín, không viền) khi bấm F11.

## Threading + Cancel + should_retry_hint -- mới thêm

- **Enter (AI giải) và H (Gợi ý)** giờ chạy trên thread riêng -- không
  còn đơ khung hình. Đã xác nhận qua ảnh chụp thật: kéo được camera xoay
  ngay trong lúc AI đang tính.
- **Esc**: hủy job đang chạy giữa chừng (cờ hủy kiểm tra mỗi 512 node
  trong các vòng lặp search, giống search_utils.py bản Python). Đã xác
  nhận: hủy xong cube giữ nguyên trạng thái, không bị đổi sai.
- **should_retry_hint**: bấm H liên tiếp cho CÙNG giai đoạn vừa thất bại
  (cube chưa đổi gì) sẽ tự xáo thứ tự tìm kiếm thay vì lặp lại y hệt kết
  quả cũ.

**Bug đã tìm và sửa trong quá trình làm:** bấm Enter/H khi cube còn đang
animate dở (VD scramble chưa xoay xong) khiến AI tính lời giải cho state
THIẾU mất nước đang xoay dở -- nước đó áp thêm vào sau khi lời giải đã
tính xong, làm lệch 1 nước, cube tưởng đã giải nhưng thực ra sai. Đã sửa
bằng cách khoá Enter/H cho tới khi cube animate xong hẳn (hiện thông báo
rõ ràng nếu bấm quá sớm: "Doi cube animate xong da").

Đã kiểm chứng toàn bộ bằng ảnh chụp thật qua Xvfb + xdotool:
1. Xáo → đợi đúng tới khi status "Xáo xong" → Enter → đợi đủ lâu → cube
   giải ĐÚNG HOÀN TOÀN (khung 6 mặt đều 1 màu mỗi mặt).
2. Xáo xong → Enter → Esc ngay lập tức → "Đã hủy", cube giữ nguyên
   trạng thái xáo, không bị lệch.

## move_simplify / Toc do animation / Click-chon-mat -- moi them

- **move_simplify**: port dung tu solver/move_simplify.py, ap dung cho
  MOI chuoi nuoc di sinh ra (AI giai, goi y Cross/F2L/OLL/PLL) -- gop 2
  nuoc cung mat lien ke (R R -> R2, R R' -> huy), thu hoan doi 1 cap nuoc
  doi dien lien ke de tao co hoi gop them.
- **Toc do animation ([ va ])**: 2.0-30.0 rad/s, hien gia tri hien tai
  trong panel trai. Bat qua winit goc (giong F11) vi three_d::Key khong
  co bien the cho phim ngoac vuong.
- **Click chon mat + mui ten xoay**: click 1 sticker trong khung 3D (chi
  khi cube dang ranh, khong animate) -- dung `three_d::pick()` (GPU
  raycast co san trong thu vien, khong tu viet ray-plane) tim diem cham
  gan nhat, roi suy ra 1 trong 6 mat lon qua so sanh dot(diem,normal) lon
  nhat. Mat duoc chon hien vien vang trong khung 6-mat. Mui ten
  Up/Right = xoay thuan, Down/Left = nghich dao.

Da kiem chung ca 3 bang anh chup that: click trung sticker cam (mat R)
-> vien vang hien dung quanh khoi R trong khung 6-mat; bam mui ten phai
-> mat F chuyen dung mau trang (tu D), goc U-phai chuyen dung mau xanh
la (tu F) -- khop chinh xac ngu nghia nuoc R that.

## Cai thien do tin cay solver (99% giai tron ven)

Tim ra va sua 2 van de that trong qua trinh dieu tra co he thong:

1. **Bug logic trong f2l_solver.rs**: khi 1 khoi F2L tinh co da xong (do
   tac dung phu cua khoi truoc do), code danh dau "da xong" nhung QUEN
   them vao danh sach can bao ve -- khien cac khoi sau tu do pha vo no
   ma khong bi phat. Da xac nhan bang cach ap dung that cac nuoc di: 1
   khoi bao "xong" nhung `pair_ok()` cuoi cung van false. Sua 1 dong.

2. **Ngan sach node F2L qua nho (200k)**: khong phai do do sau tim kiem
   khong du -- kiem chung bang cach giu nguyen do sau nhung tang ngan
   sach len 400k thi giai duoc, con giu ngan sach nhung tang do sau len
   18 thi van that bai. Da tang len 400k (do thuc te: nhanh HON vi it
   phai retry qua nhieu tier that bai).

**Ket qua do duoc**: ty le giai tron ven tang tu ~90-92% len **99%
(198/200 scramble)**. Toan bo 20/20 test goc van pass.
